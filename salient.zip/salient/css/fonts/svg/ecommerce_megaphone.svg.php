<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.0"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<polygon fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="1,29 1,35 7,41 45.5,41 61,53 63,53 63,29 
	63,5 61,5 45.5,17 7,17 1,23 "/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="19,41 12,59 18,59 28,41 "/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="43" y1="17" x2="43" y2="41"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="36" y1="41" x2="36" y2="17"/>
</svg>
