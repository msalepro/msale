<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="12" y1="19" x2="12" y2="64"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="52" y1="0" x2="52" y2="45"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="32" y1="38" x2="32" y2="64"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="32" y1="0" x2="32" y2="26"/>
<circle fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" cx="12" cy="13" r="6"/>
<circle fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" cx="52" cy="51" r="6"/>
<circle fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" cx="32" cy="32" r="6"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="12" y1="0" x2="12" y2="7"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="52" y1="57" x2="52" y2="64"/>
</svg>
